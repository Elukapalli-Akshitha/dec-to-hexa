def decimal_to_hexadecimal(decimal_num):
    try:
        decimal_num=int(decimal_num)
    except ValueError:
        return "Invalid input: not a decimal number"
    hex_map={10: 'A', 11: 'B', 12: 'C', 13: 'D', 14: 'E', 15: 'F'}
    quotient=decimal_num
    hexadecimal=""
    while quotient>0:
        remainder=quotient%16 
        if remainder>=10:
            hexadecimal=hex_map[remainder]+hexadecimal
        else:
            hexadecimal=str(remainder)+hexadecimal
        quotient=quotient//16 
    return hexadecimal if hexadecimal else "0"
decimal_num=input()
hexadecimal_num=decimal_to_hexadecimal(decimal_num)
print("Hexadecimal:", hexadecimal_num)